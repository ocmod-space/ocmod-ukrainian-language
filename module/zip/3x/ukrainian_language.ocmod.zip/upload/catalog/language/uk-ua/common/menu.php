<?php

// Text
$_['text_all'] = 'Показати усі';
$_['text_category'] = 'Категорії';
