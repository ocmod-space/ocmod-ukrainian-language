<?php

// Heading
$_['heading_title'] = 'Особистий кабінет';

// Text
$_['text_account'] = 'Особистий кабінет';
$_['text_my_account'] = 'Мій обліковий запис';
$_['text_my_orders'] = 'Мої замовлення';
$_['text_my_affiliate'] = 'Кабінет партнера';
$_['text_my_newsletter'] = 'Email-розсилка';
$_['text_edit'] = 'Змінити контактну інформацію';
$_['text_password'] = 'Змінити пароль';
$_['text_address'] = 'Змінити мої адреси';
$_['text_credit_card'] = 'Керування кредитними картами';
$_['text_account_wishlist'] = 'Показати обране';
$_['text_order'] = 'Історія замовлень';
$_['text_download'] = 'Файли для завантаження';
$_['text_reward'] = 'Бонусні бали';
$_['text_return'] = 'Запити на повернення';
$_['text_transaction'] = 'Історія транзакцій';
$_['text_newsletter'] = 'Email-розсилка';
$_['text_recurring'] = 'Періодичні платежі';
$_['text_transactions'] = 'Транзакції';
$_['text_affiliate_add'] = 'Реєстрація у партнерській програмі';
$_['text_affiliate_edit'] = 'Редагувати інформацію партнера';
$_['text_tracking'] = 'Редагувати партнерське посилання';
