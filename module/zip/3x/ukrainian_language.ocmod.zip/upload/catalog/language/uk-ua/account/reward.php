<?php

// Heading
$_['heading_title'] = 'Бонусні бали';

// Column
$_['column_date_added'] = 'Додано';
$_['column_description'] = 'Опис';
$_['column_points'] = 'Бонусні бали';

// Text
$_['text_account'] = 'Особистий Кабінет';
$_['text_reward'] = 'Бонусні бали';
$_['text_total'] = 'Накопичено бонусних балів';
$_['text_empty'] = 'У Вас немає бонусних балів!';
