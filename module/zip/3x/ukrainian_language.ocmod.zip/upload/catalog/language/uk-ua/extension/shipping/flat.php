<?php

// Text
$_['text_title'] = 'Фіксована доставки';
$_['text_description'] = 'Доставка з фіксованою вартістю';
