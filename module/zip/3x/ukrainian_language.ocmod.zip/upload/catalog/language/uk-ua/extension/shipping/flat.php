<?php

// Text
$_['text_title'] = 'Платна доставка';
$_['text_description'] = 'Фіксована вартість доставки';
