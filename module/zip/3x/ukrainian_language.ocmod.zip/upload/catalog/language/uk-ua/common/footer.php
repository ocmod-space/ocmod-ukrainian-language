<?php

// Text
$_['text_information'] = 'Інформація';
$_['text_service'] = 'Служба підтримки';
$_['text_extra'] = 'Додатково';
$_['text_contact'] = 'Контакти';
$_['text_return'] = 'Повернення товару';
$_['text_sitemap'] = 'Карта сайту';
$_['text_manufacturer'] = 'Виробники';
$_['text_voucher'] = 'Подарункові сертифікати';
$_['text_affiliate'] = 'Партнерська програма';
$_['text_special'] = 'Акції';
$_['text_account'] = 'Особистий кабінет';
$_['text_order'] = 'Історія замовлень';
$_['text_wishlist'] = 'Обране';
$_['text_newsletter'] = 'Підписка на email-розсилку';
$_['text_powered'] = '%s &copy; %s<br />За підтримки <a href="https://github.com/ocmod-space/">ocmod.space</a>';
