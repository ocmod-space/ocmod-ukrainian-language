<?php

// Heading
$_['heading_title'] = 'Підписка на новини';

// Text
$_['text_account'] = 'Особистий кабінет';
$_['text_newsletter'] = 'Email-розсилка';
$_['text_success'] = 'Вашу підписку успішно оновлена!';

// Entry
$_['entry_newsletter'] = 'Підписатися';
