<?php

$_['text_credit'] = 'Кредит магазину';
$_['text_order_id'] = '№ Замовлення: %s';
