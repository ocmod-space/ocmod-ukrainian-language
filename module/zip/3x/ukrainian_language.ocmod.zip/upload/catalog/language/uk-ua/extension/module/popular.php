<?php

// Heading
$_['heading_title'] = 'Популярні Товари';

// Text
$_['text_reviews'] = 'На основі %s відгуків.';

// Tax
$_['text_tax'] = 'Без ПДВ:';
