<?php

// Text
$_['text_title'] = 'Післяплата';
