<?php

// Text
$_['text_title'] = 'При отриманні';
