<?php

// Text
$_['text_items'] = '%s товар(ів) - %s';
$_['text_empty'] = 'Кошик порожній!';
$_['text_cart'] = 'Перейти до кошика';
$_['text_checkout'] = 'Оформити замовлення';
$_['text_recurring'] = 'Платіжний профіль';
