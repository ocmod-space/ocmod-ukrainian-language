<?php

// Heading
$_['heading_title'] = 'Зовнішні вивантаження';

// Text
$_['text_success'] = 'Виконано!';
$_['text_list'] = 'Зовнішні вивантаження';

// Column
$_['column_name'] = 'Назва Файлу';
$_['column_filename'] = 'Ім&apos;я Файлу';
$_['column_date_added'] = 'Додано';
$_['column_action'] = 'Дія';

// Entry
$_['entry_name'] = 'Назва Файлу';
$_['entry_filename'] = 'Ім&apos;я Файлу';
$_['entry_date_added'] = 'Додано';

// Error
$_['error_permission'] = 'Увага! У Вас недостатньо прав доступу, зерніться до адміністратора!';
