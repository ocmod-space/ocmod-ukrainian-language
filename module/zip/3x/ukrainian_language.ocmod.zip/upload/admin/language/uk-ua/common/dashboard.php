<?php

// Heading
$_['heading_title'] = 'Панель управління';

// Error
$_['error_install'] = 'Увага! Інсталяційна директорія install досі існує! Видаліть її.';
