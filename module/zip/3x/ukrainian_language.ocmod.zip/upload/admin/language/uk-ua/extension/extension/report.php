<?php

// Heading
$_['heading_title'] = 'Звіти';

// Text
$_['text_success'] = 'Виконано! Ви змінили звіти!';
$_['text_list'] = 'Список звітів';

// Column
$_['column_name'] = 'Назва звіту';
$_['column_status'] = 'Статус';
$_['column_sort_order'] = 'Сортування';
$_['column_action'] = 'Дія';

// Error
$_['error_permission'] = 'Увага! У Вас недостатньо прав доступу, зерніться до адміністратора!';
