<?php

// Heading
$_['heading_title'] = 'Other';

// Text
$_['text_success'] = 'Виконано! Налаштування були успішно змінені!';
$_['text_list'] = 'Other List';

// Column
$_['column_name'] = 'Other';
$_['column_status'] = 'Status';
$_['column_action'] = 'Action';

// Error
$_['error_permission'] = 'Увага! Недостатньо прав для доступу чи редагування, зверніться до адміністратора!';
