<?php

// Heading
$_['heading_title'] = 'Переклад';

// Text
$_['text_edit'] = 'Налаштування';
$_['text_list'] = 'Переклад';
$_['text_translation'] = 'Вибрати';
$_['text_translation'] = 'Вибрати';

// Column
$_['column_flag'] = 'Прапор';
$_['column_country'] = 'Країна';
$_['column_progress'] = 'Процес перекладу';
$_['column_action'] = 'Дія';

// button
$_['button_install'] = 'Встановити';
$_['button_uninstall'] = 'Видалити';
$_['button_refresh'] = 'Оновити';

// Error
$_['error_permission'] = 'Увага! Недостатньо прав для доступу чи редагування, зверніться до адміністратора!';
