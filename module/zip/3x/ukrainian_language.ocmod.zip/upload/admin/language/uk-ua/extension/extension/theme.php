<?php

// Heading
$_['heading_title'] = 'Теми';

// Text
$_['text_success'] = 'Налаштування успішно оновлені!';
$_['text_list'] = 'Список тем';

// Column
$_['column_name'] = 'Назва';
$_['column_status'] = 'Статус';
$_['column_action'] = 'Дія';

// Error
$_['error_permission'] = 'Увага! Недостатньо прав для доступу чи редагування, зверніться до адміністратора!';
