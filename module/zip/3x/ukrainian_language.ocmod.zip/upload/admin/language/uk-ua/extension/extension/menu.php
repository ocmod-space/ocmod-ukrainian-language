<?php

// Heading
$_['heading_title'] = 'Меню';

// Text
$_['text_success'] = 'Виконано! Ви змінили меню!';
$_['text_list'] = 'Список меню';

// Column
$_['column_name'] = 'Назва меню';
$_['column_status'] = 'Статус';
$_['column_action'] = 'Дія';

// Error
$_['error_permission'] = 'Увага! У Вас недостатньо прав доступу, зерніться до адміністратора!';
