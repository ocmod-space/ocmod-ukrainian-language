<?php

// Heading
$_['heading_title'] = 'Google Sitemap';

// Text
$_['text_extension'] = 'Розширення';
$_['text_success'] = 'Налаштування модуля оновлено!';
$_['text_edit'] = 'Редагувати';

// Entry
$_['entry_status'] = 'Статус';
$_['entry_data_feed'] = 'Адреса';

// Error
$_['error_permission'] = 'Увага! У Вас недостатньо прав доступу, зерніться до адміністратора!';
