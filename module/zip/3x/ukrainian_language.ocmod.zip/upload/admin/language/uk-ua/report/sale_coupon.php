<?php

// Heading
$_['heading_title'] = 'Звіт по купонах';

// Text
$_['text_list'] = 'Купони';

// Column
$_['column_name'] = 'Ім&#39;я купона';
$_['column_code'] = 'Код';
$_['column_orders'] = 'Кількість замовлень';
$_['column_total'] = 'Разом';
$_['column_action'] = 'Дія';

// Entry
$_['entry_date_start'] = 'Дата';
$_['entry_date_end'] = 'Дата закінчення';
