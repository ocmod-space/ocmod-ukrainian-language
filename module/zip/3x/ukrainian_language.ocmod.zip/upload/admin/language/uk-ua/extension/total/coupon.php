<?php

// Heading
$_['heading_title'] = 'Купони';

// Text
$_['text_total'] = 'Враховувати в замовленні';
$_['text_success'] = 'Налаштування були успішно змінені!';
$_['text_edit'] = 'Налаштування';

// Entry
$_['entry_status'] = 'Статус';
$_['entry_sort_order'] = 'Порядок сортування';

// Error
$_['error_permission'] = 'Увага! У Вас недостатньо прав доступу, зерніться до адміністратора!';
