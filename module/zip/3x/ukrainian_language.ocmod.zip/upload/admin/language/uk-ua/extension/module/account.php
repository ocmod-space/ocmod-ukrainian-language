<?php

// Heading
$_['heading_title'] = 'Акаунт';

// Text
$_['text_extension'] = 'Розширення';
$_['text_success'] = 'Налаштування були успішно змінені!';
$_['text_edit'] = 'Налаштування модуля';

// Entry
$_['entry_status'] = 'Статус';

// Error
$_['error_permission'] = 'Увага! У Вас недостатньо прав доступу, зерніться до адміністратора!';
