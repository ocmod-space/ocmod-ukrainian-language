<?php

// Heading
$_['heading_title'] = 'Доставка';

// Text
$_['text_extension'] = 'Розширення';
$_['text_success'] = 'Налаштування були успішно змінені!';
$_['text_edit'] = 'Налаштування';

// Entry
$_['entry_estimator'] = 'Оцінка вартості доставки';
$_['entry_status'] = 'Статус';
$_['entry_sort_order'] = 'Порядок сортування';

// Error
$_['error_permission'] = 'Увага! Недостатньо прав для доступу чи редагування, зверніться до адміністратора!';
