<?php

// Heading
$_['heading_title'] = 'Клієнти онлайн';

// Text
$_['text_list'] = 'Список онлайн клієнтів';
$_['text_guest'] = 'Гість';

// Column
$_['column_ip'] = 'IP';
$_['column_customer'] = 'Клієнт';
$_['column_url'] = 'Остання переглянуте сторінка';
$_['column_referer'] = 'Реферал';
$_['column_date_added'] = 'Останній клік';
$_['column_action'] = 'Дія';

// Entry
$_['entry_ip'] = 'IP';
$_['entry_customer'] = 'Клієнт';
