<?php

// Text
$_['text_footer'] = '<a href="https://www.ocmod.space" target="_blank">ocmod.space - розробка рішень для OpenCart.</a>';
