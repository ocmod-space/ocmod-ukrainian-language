<?php

// Text
$_['text_footer'] = '<a href="https://www.ocmod.space" target="_blank">www.ocmod.space</a> - розробка рішень для OpenCart.';
