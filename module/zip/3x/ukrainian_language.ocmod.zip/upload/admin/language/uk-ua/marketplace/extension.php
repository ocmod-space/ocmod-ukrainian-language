<?php

// Heading
$_['heading_title'] = 'Розширення';

// Text
$_['text_success'] = 'Виконано! Ви змінили модуль!';
$_['text_list'] = 'Список розширень';
$_['text_type'] = 'Оберіть тип модуля';
$_['text_filter'] = 'Фільтр';
