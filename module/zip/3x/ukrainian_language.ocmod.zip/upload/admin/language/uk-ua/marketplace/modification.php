<?php

// Heading
$_['heading_title'] = 'Модифікатори';

// Text
$_['text_success'] = 'Успіх: Ви змінили Модифікатори!';
$_['text_refresh'] = 'Щоразу, коли ви вмикаєте / вимикаєте або видаляєте Модифікацію, потрібно натиснути кнопку оновлення, щоб відновити кеш Модифікація!';
$_['text_list'] = 'Модифікація List';

// Column
$_['column_name'] = 'Модифікація Name';
$_['column_author'] = 'Автор';
$_['column_version'] = 'Версія';
$_['column_status'] = 'Статус';
$_['column_date_added'] = 'Дата';
$_['column_action'] = 'Дія';

// Error
$_['error_permission'] = 'Увага: у вас немає дозволу на зміну модифікаторів!';
