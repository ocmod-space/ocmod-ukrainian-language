<?php

// Heading
$_['heading_title'] = 'Редактор мов';

// Text
$_['text_success'] = 'Виконано! Налаштування були успішно змінені!';
$_['text_edit'] = 'Налаштування';
$_['text_default'] = 'За замовчуванням';
$_['text_store'] = 'Магазин';
$_['text_language'] = 'Мова';
$_['text_translation'] = 'Вибрати переклад';
$_['text_translation'] = 'Вибрати переклад';

// Entry
$_['entry_key'] = 'Ключ';
$_['entry_value'] = 'Значення';
$_['entry_default'] = 'За замовчуванням';

// Error
$_['error_permission'] = 'Увага! Недостатньо прав для доступу чи редагування, зверніться до адміністратора!';
