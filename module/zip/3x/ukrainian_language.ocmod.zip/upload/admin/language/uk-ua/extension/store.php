<?php

// Heading
$_['heading_title'] = 'Магазин розширень і тим';

// Text
$_['text_success'] = 'Налаштування були успішно змінені!';
$_['text_list'] = 'Список';
$_['text_license'] = 'Ліцензія';
$_['text_free'] = 'Безкоштовно';
$_['text_commercial'] = 'Платно';
$_['text_category'] = 'категорії';
$_['text_theme'] = 'Теми';
$_['text_payment'] = 'Оплата';
$_['text_shipping'] = 'Доставка';
$_['text_module'] = 'Модулі';
$_['text_total'] = 'Враховувати в замовленні';
$_['text_feed'] = 'Просування';
$_['text_report'] = 'Звіти';
$_['text_other'] = 'Інше';

// Error
$_['error_permission'] = 'Увага! Недостатньо прав для доступу чи редагування, зверніться до адміністратора!';
