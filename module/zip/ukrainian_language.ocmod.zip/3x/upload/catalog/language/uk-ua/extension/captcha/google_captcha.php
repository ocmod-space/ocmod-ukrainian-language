<?php

// Heading
$_['text_captcha'] = 'Захист від роботів';

// Entry
$_['entry_captcha'] = 'Введіть код в поле нижче';

// Error
$_['error_captcha'] = 'Код перевірки не співпадає із зображенням!';
